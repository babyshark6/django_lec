from django.contrib import admin
from .models import MainContent

admin.site.register(MainContent)


# django_lec2
django project2
